# Bootstrap Admin Page Example

A Pen created on CodePen.

Original URL: [https://codepen.io/htschmed/pen/EEGJZY](https://codepen.io/htschmed/pen/EEGJZY).

